# Art Class Pinocy – React版コンポーネント
このファイルは GitHub Pages の `index.html` とは別の、**React 用コンポーネント**です。
- リポジトリに保存する場合は `react/ArtClassPinocy.jsx` というパスで置くのが分かりやすいです。
- GitHub Pages の表示は `index.html` が担当します（React版は直接は表示されません）。
- React で動かす場合は、Vite や Next.js プロジェクトにこのコンポーネントを組み込んでください。

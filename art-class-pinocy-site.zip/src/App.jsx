import { useMemo } from 'react'
import { Calendar, Paintbrush, User, MapPin, JapaneseYen, Clock, MessageCircle } from 'lucide-react'

const lineUrl = 'https://lin.ee/ikPeDRw'

export default function App() {
  const features = useMemo(() => [
    { icon: <Paintbrush className="w-6 h-6" aria-hidden />, title: '内容', text: 'アクリル画・水彩画・デッサン・クロッキーなど。さまざまな画材や技法を体験しながら作品づくり。' },
    { icon: <User className="w-6 h-6" aria-hidden />, title: '講師', text: '美大卒／美術科教員免許あり。イラストレーターの千尋が丁寧にサポートします。' },
    { icon: <Calendar className="w-6 h-6" aria-hidden />, title: '開催', text: '月2回・予約制（お好きな日時を選べます）／毎週土曜 10:00–11:30・14:00–15:30' },
    { icon: <MapPin className="w-6 h-6" aria-hidden />, title: '場所', text: '箕面市桜ヶ丘3丁目（詳しくはLINEでご案内）' },
  ], [])

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-slate-50 text-slate-800">
      <header className="sticky top-0 z-40 backdrop-blur bg-white/70 border-b">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <a href="#top" className="font-bold text-xl tracking-tight">ART CLASS PINOCY</a>
          <nav className="hidden md:flex gap-6 text-sm">
            <a href="#about" className="hover:opacity-70">教室について</a>
            <a href="#schedule" className="hover:opacity-70">スケジュール</a>
            <a href="#price" className="hover:opacity-70">料金</a>
            <a href="#instructor" className="hover:opacity-70">講師</a>
            <a href="#faq" className="hover:opacity-70">FAQ</a>
            <a href="#access" className="hover:opacity-70">アクセス</a>
          </nav>
          <a href={lineUrl} target="_blank" rel="noreferrer" aria-label="公式LINEで問い合わせ" className="px-4 py-2 rounded-2xl bg-indigo-600 text-white hover:opacity-90">公式LINEで問い合わせ</a>
        </div>
      </header>

      <section id="top" className="max-w-6xl mx-auto px-4 pt-16 pb-10 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h1 className="text-4xl md:text-5xl font-extrabold leading-tight">
            幼児から大人まで楽しめる、<br />
            <span className="bg-gradient-to-r from-indigo-600 to-sky-500 bg-clip-text text-transparent">もう一歩深い“アートの世界”</span>
          </h1>
          <p className="mt-6 text-lg text-slate-600">
            自由な発想を思い切り表現しながら、新しい感性や技術を楽しく学べる教室です。画材はすべてご用意。汚れてもいい服装でご参加ください。
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href={lineUrl} target="_blank" rel="noreferrer" className="px-5 py-3 rounded-2xl bg-indigo-600 text-white inline-flex items-center">
              <MessageCircle className="mr-2 h-5 w-5"/>体験レッスンを問い合わせ
            </a>
            <a href="#price" className="px-5 py-3 rounded-2xl border hover:shadow">料金を見る</a>
          </div>
          <p className="mt-3 text-sm text-slate-500">対象：年少さんから大人の方まで</p>
        </div>
        <div className="relative">
          <div className="aspect-[4/3] rounded-2xl bg-white shadow-xl ring-1 ring-slate-200 p-4 grid grid-cols-2 gap-3">
            <div className="rounded-xl bg-slate-50 p-4 flex flex-col justify-between">
              <div className="flex items-center gap-2"><Paintbrush /><span className="font-semibold">さまざまな技法</span></div>
              <ul className="text-sm text-slate-600 list-disc pl-5 space-y-1">
                <li>アクリル画</li>
                <li>水彩画</li>
                <li>デッサン</li>
                <li>クロッキー</li>
              </ul>
            </div>
            <div className="rounded-xl bg-slate-50 p-4 flex flex-col justify-between">
              <div className="flex items-center gap-2"><Clock /><span className="font-semibold">毎週土曜</span></div>
              <div className="text-sm text-slate-600">
                10:00–11:30<br />14:00–15:30
              </div>
              <div className="flex items-center gap-2 mt-4"><MapPin /><span className="text-sm">箕面市桜ヶ丘3丁目</span></div>
            </div>
            <div className="col-span-2 rounded-xl bg-gradient-to-r from-indigo-50 to-sky-50 p-4 flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-500">予約制／月2回</p>
                <p className="font-semibold">あなたのペースで通えます</p>
              </div>
              <a href={lineUrl} target="_blank" rel="noreferrer" className="px-4 py-2 rounded-xl border">LINEで質問する</a>
            </div>
          </div>
        </div>
      </section>

      <section id="about" className="max-w-6xl mx-auto px-4 py-14">
        <div className="grid md:grid-cols-4 gap-6">
          {features.map((f, i) => (
            <div key={i} className="rounded-2xl border p-5">
              <div className="flex items-center gap-3 mb-2">{f.icon}<div className="font-semibold">{f.title}</div></div>
              <div className="text-sm text-slate-600">{f.text}</div>
            </div>
          ))}
        </div>
      </section>

      <section id="schedule" className="bg-white border-y">
        <div className="max-w-6xl mx-auto px-4 py-14">
          <h2 className="text-2xl md:text-3xl font-bold">スケジュール</h2>
          <p className="mt-2 text-slate-600">毎週土曜日／各90分・予約制（お好きな日時を選べます）</p>
          <div className="mt-6 grid md:grid-cols-2 gap-4">
            <div className="rounded-2xl border p-5"><div className="font-semibold flex items-center gap-2"><Clock className="w-5 h-5"/>午前クラス</div><div className="text-lg mt-2">10:00 – 11:30</div></div>
            <div className="rounded-2xl border p-5"><div className="font-semibold flex items-center gap-2"><Clock className="w-5 h-5"/>午後クラス</div><div className="text-lg mt-2">14:00 – 15:30</div></div>
          </div>
          <div className="mt-6">
            <a href={lineUrl} target="_blank" rel="noreferrer" className="px-5 py-3 rounded-2xl bg-indigo-600 text-white inline-block">空き状況を問い合わせる</a>
          </div>
        </div>
      </section>

      <section id="price" className="max-w-6xl mx-auto px-4 py-14">
        <h2 className="text-2xl md:text-3xl font-bold">料金</h2>
        <p className="mt-2 text-slate-600">画材はすべてこちらでご用意します。</p>
        <div className="mt-6 grid md:grid-cols-3 gap-6">
          <div className="rounded-2xl border p-5">
            <div className="text-xl font-semibold">体験レッスン</div>
            <p className="text-3xl font-extrabold flex items-center gap-2 mt-3"><JapaneseYen className="w-6 h-6"/>2,000</p>
            <p className="text-sm text-slate-600 mt-2">初回1回のみ／90分</p>
            <a href={lineUrl} target="_blank" rel="noreferrer" className="mt-4 rounded-2xl w-full bg-slate-100 px-4 py-2 inline-block text-center">体験を申し込む</a>
          </div>

          <div className="rounded-2xl border p-5 ring-1 ring-indigo-100 relative overflow-hidden shadow-sm">
            <div className="absolute top-3 right-3 text-xs bg-indigo-600 text-white px-2 py-1 rounded-full">おすすめ</div>
            <div className="text-xl font-semibold">教室（レギュラー）</div>
            <p className="text-3xl font-extrabold flex items-center gap-2 mt-3"><JapaneseYen className="w-6 h-6"/>4,000</p>
            <p className="text-sm text-slate-600 mt-2">月2回・予約制／各90分</p>
            <ul className="mt-3 text-sm text-slate-600 list-disc pl-5 space-y-1">
              <li>振替相談OK</li>
              <li>年少〜大人まで同じ料金</li>
            </ul>
            <a href={lineUrl} target="_blank" rel="noreferrer" className="mt-4 rounded-2xl w-full bg-indigo-600 text-white px-4 py-2 inline-block text-center">申し込む</a>
          </div>

          <div className="rounded-2xl border p-5 text-sm text-slate-600 space-y-2">
            <div className="text-xl font-semibold text-slate-800">ご案内</div>
            <p>汚れてもよい服装でご参加ください。</p>
            <p>対象：年少さんから大人の方まで。</p>
            <p>まずは体験からでもOK。お気軽にご相談ください。</p>
          </div>
        </div>
      </section>

      <section id="instructor" className="bg-white border-y">
        <div className="max-w-6xl mx-auto px-4 py-14 grid md:grid-cols-3 gap-10 items-start">
          <div className="md:col-span-2">
            <h2 className="text-2xl md:text-3xl font-bold">講師紹介</h2>
            <p className="mt-4 text-slate-700 leading-relaxed">
              講師はイラストレーターの<strong>千尋</strong>。美大卒で美術科教員免許を所持。表現の“コツ”を丁寧にお伝えしながら、
              それぞれの個性を大切に伸ばしていきます。作品を通じて自分の感性に気づき、新しい表現方法を一緒に発見しましょう。
            </p>
          </div>
          <div className="bg-slate-50 rounded-2xl p-5 ring-1 ring-slate-200">
            <h3 className="font-semibold mb-3">ポイント</h3>
            <ul className="text-sm text-slate-600 space-y-2 list-disc pl-5">
              <li>一人ひとりに合わせた丁寧な指導</li>
              <li>多様な画材・技法を体験</li>
              <li>完成までしっかりサポート</li>
            </ul>
          </div>
        </div>
      </section>

      <section id="faq" className="max-w-6xl mx-auto px-4 py-14">
        <h2 className="text-2xl md:text-3xl font-bold">よくある質問</h2>
        <div className="mt-6 grid md:grid-cols-2 gap-6">
          <div className="rounded-2xl border p-5"><div className="font-semibold">絵が初めてでも大丈夫？</div><div className="text-sm text-slate-600 mt-2">もちろん大丈夫です。道具はすべてこちらで用意し、レベルに合わせてサポートします。</div></div>
          <div className="rounded-2xl border p-5"><div className="font-semibold">振替は可能ですか？</div><div className="text-sm text-slate-600 mt-2">事前にご連絡いただければ、別日程への振替をご相談いただけます。</div></div>
          <div className="rounded-2xl border p-5"><div className="font-semibold">どんな服装で行けばいい？</div><div className="text-sm text-slate-600 mt-2">絵の具などで汚れることがあります。汚れてもよい服装でお越しください。</div></div>
          <div className="rounded-2xl border p-5"><div className="font-semibold">場所の詳細は？</div><div className="text-sm text-slate-600 mt-2">箕面市桜ヶ丘3丁目です。詳しい住所は安全のため、公式LINEで個別にご案内します。</div></div>
        </div>
      </section>

      <section id="access" className="bg-indigo-50">
        <div className="max-w-6xl mx-auto px-4 py-14 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-2xl md:text-3xl font-bold">アクセス</h2>
            <p className="mt-2 text-slate-700">大阪府箕面市桜ヶ丘3丁目（詳しくはLINEでご案内）</p>
            <div className="mt-6">
              <a href={lineUrl} target="_blank" rel="noreferrer" className="px-5 py-3 rounded-2xl bg-indigo-600 text-white inline-flex items-center"><MapPin className="mr-2 h-5 w-5"/>場所の詳細を問い合わせる</a>
            </div>
          </div>
          <div className="rounded-2xl bg-white p-6 ring-1 ring-indigo-100 shadow-sm">
            <h3 className="font-semibold">まずは体験から</h3>
            <p className="text-sm text-slate-600 mt-2">90分の体験レッスン（2,000円）。教室の雰囲気をご確認いただけます。</p>
            <div className="mt-4 flex gap-3">
              <a href={lineUrl} target="_blank" rel="noreferrer" className="px-4 py-2 rounded-2xl bg-indigo-600 text-white">体験を申し込む</a>
              <a href={lineUrl} target="_blank" rel="noreferrer" className="px-4 py-2 rounded-2xl border">質問する</a>
            </div>
          </div>
        </div>
      </section>

      <footer className="py-10">
        <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-slate-500">
          <p>© {new Date().getFullYear()} ART CLASS PINOCY</p>
          <div className="flex items-center gap-4">
            <a href={lineUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 hover:opacity-80">
              <MessageCircle className="w-4 h-4"/> 公式LINE
            </a>
          </div>
        </div>
      </footer>
    </div>
  )
}

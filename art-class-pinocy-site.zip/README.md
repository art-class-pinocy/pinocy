# ART CLASS PINOCY (GitHub Pages)

## 開発
```bash
npm install
npm run dev
```

## ビルド
```bash
npm run build
```

## デプロイ（GitHub Pages）
- リポジトリの **Settings → Pages** で「Build and deployment: GitHub Actions」を選択
- `package.json` の `homepage` と `vite.config.js` の `base` を自分のユーザー名／リポジトリ名に変更
- main ブランチに push すると自動でデプロイされます

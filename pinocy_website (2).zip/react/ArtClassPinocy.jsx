import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Paintbrush, Calendar, MapPin, Leaf, Clock, Users } from "lucide-react";

export default function ArtClassPinocy() {
  const features = [
    {
      icon: <Paintbrush className="h-6 w-6" aria-hidden />,
      title: "多彩なプログラム",
      desc: "アクリル画・水彩画・デッサン・クロッキーなど。楽しく作りながら上達します。",
    },
    {
      icon: <Users className="h-6 w-6" aria-hidden />,
      title: "対象: 年少〜大人",
      desc: "幅広い年齢に合わせて、安心して学べるカリキュラムを用意。",
    },
    {
      icon: <Calendar className="h-6 w-6" aria-hidden />,
      title: "月2回・予約制",
      desc: "お好きな日時を選べます。毎週土曜日は定期クラスも開催。",
    },
    {
      icon: <Leaf className="h-6 w-6" aria-hidden />,
      title: "道具は教室で用意",
      desc: "手ぶらでOK。汚れてもよい服装でお越しください。",
    },
  ];

  const schedule = [
    { time: "10:00–11:30", note: "毎週土曜日" },
    { time: "14:00–15:30", note: "毎週土曜日" },
  ];

  const pricing = [
    { name: "体験(1回)", price: "¥2,000", details: "まずは雰囲気をお試し" },
    { name: "月2回", price: "¥4,000", details: "継続して通いたい方に" },
  ];

  return (
    <div className="min-h-screen bg-amber-50 text-stone-900">
      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur bg-amber-50/80 border-b">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 grid place-items-center rounded-full bg-lime-200 border">
              <Leaf className="h-6 w-6" aria-hidden />
            </div>
            <div>
              <p className="text-xs uppercase tracking-widest text-stone-500">Art class</p>
              <p className="text-2xl font-black tracking-tight">Pinocy</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#about" className="hover:opacity-80">教室について</a>
            <a href="#classes" className="hover:opacity-80">クラス&料金</a>
            <a href="#schedule" className="hover:opacity-80">スケジュール</a>
            <a href="#access" className="hover:opacity-80">アクセス</a>
          </nav>
          <Button asChild className="rounded-2xl">
            <a href="#contact">LINEで予約</a>
          </Button>
        </div>
      </header>
      {/* 以下省略（全文はキャンバスに保存済み） */}
    </div>
  );
}